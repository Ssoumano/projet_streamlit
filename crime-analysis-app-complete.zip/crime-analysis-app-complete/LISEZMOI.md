# 🚀 INSTALLATION RAPIDE

## Étapes d'installation (5 minutes)

### 1️⃣ Extraire le ZIP
Décompressez le fichier ZIP dans le dossier de votre choix.

### 2️⃣ Ajouter vos données
Dans le dossier `data/`, placez :
- `data-gouv-series-chrono.xlsx` (votre fichier Excel)
- `regions-20180101-shp/` (dossier avec vos fichiers shapefile)

Voir `data/README_DATA.md` pour plus de détails.

### 3️⃣ Installer les dépendances
Ouvrez un terminal dans ce dossier et exécutez :

```bash
pip install -r requirements.txt
```

### 4️⃣ Lancer l'application
```bash
streamlit run app.py
```

L'application s'ouvrira automatiquement dans votre navigateur !

---

## 📚 Documentation complète

Consultez le dossier `docs/` pour :
- **README.md** - Documentation complète
- **QUICKSTART.md** - Guide de démarrage rapide
- **DEVELOPER.md** - Guide développeur
- **MIGRATION_GUIDE.md** - Comment réorganiser vos fichiers existants
- **DATA_SETUP_GUIDE.md** - Guide configuration des données

---

## 🆘 Problèmes ?

### "Module not found"
```bash
pip install -r requirements.txt
```

### "File not found"
Vérifiez que vos données sont dans `data/` avec la bonne structure.

### Port déjà utilisé
```bash
streamlit run app.py --server.port 8502
```

---

## 📁 Structure du projet

```
crime-analysis-app-complete/
├── app.py                    # Point d'entrée principal
├── config.py                 # Configuration
├── requirements.txt          # Dépendances
│
├── pages/                    # Pages de l'application
│   ├── __init__.py
│   ├── home.py              # Page d'accueil
│   ├── analyses.py          # Analyses détaillées
│   └── cartography.py       # Cartographie
│
├── utils/                    # Modules utilitaires
│   ├── __init__.py
│   ├── data_loader.py       # Chargement données
│   ├── visualizations.py    # Graphiques
│   └── predictions.py       # Prédictions
│
├── data/                     # VOS DONNÉES ICI
│   └── README_DATA.md       # Instructions
│
├── .streamlit/              # Configuration Streamlit
│   └── config.toml
│
└── docs/                    # Documentation
    ├── README.md
    ├── QUICKSTART.md
    ├── DEVELOPER.md
    └── ...
```

---

## ✅ Prêt !

Une fois vos données en place, lancez :

```bash
streamlit run app.py
```

Bon développement ! 🎉
