"""
Package des pages de l'application
"""
from . import home
from . import analyses
from . import cartography

__all__ = ['home', 'analyses', 'cartography']
