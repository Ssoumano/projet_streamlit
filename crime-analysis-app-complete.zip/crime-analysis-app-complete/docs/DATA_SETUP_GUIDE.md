# 📁 Guide de Configuration du Dossier Data

## Structure requise

Créez cette structure dans votre projet :

```
crime-analysis-app/
└── data/
    ├── data-gouv-series-chrono.xlsx
    └── regions-20180101-shp/
        ├── regions-20180101.shp
        ├── regions-20180101.shx
        ├── regions-20180101.dbf
        └── regions-20180101.prj
```

## 📥 Où trouver les données

### 1. Données de criminalité (Excel)
**Fichier:** `data-gouv-series-chrono.xlsx`

**Source:** Data.gouv.fr
- URL: https://www.data.gouv.fr
- Rechercher: "criminalité" ou "délinquance"
- Télécharger le fichier Excel des séries chronologiques

**Vous avez déjà ce fichier !** Déplacez-le simplement dans `data/`

### 2. Shapefile des régions (Géographie)
**Dossier:** `regions-20180101-shp/`

**Source:** IGN ou Data.gouv.fr
- URL: https://www.data.gouv.fr/fr/datasets/contours-des-regions-francaises-sur-openstreetmap/
- Télécharger le fichier ZIP "Régions 2018"
- Décompresser dans `data/`

**Vous avez déjà ces fichiers !** Déplacez le dossier dans `data/`

## 🔧 Commandes pour créer la structure

### Sur Windows (PowerShell)
```powershell
# Dans le dossier crime-analysis-app/
New-Item -ItemType Directory -Force -Path "data"
New-Item -ItemType Directory -Force -Path "data\regions-20180101-shp"

# Puis déplacez manuellement vos fichiers dans ces dossiers
```

### Sur Mac/Linux (Terminal)
```bash
# Dans le dossier crime-analysis-app/
mkdir -p data/regions-20180101-shp

# Puis déplacez vos fichiers
# Si vos fichiers sont dans ~/Downloads/ :
cp ~/Downloads/data-gouv-series-chrono.xlsx data/
cp ~/Downloads/regions-20180101-shp/* data/regions-20180101-shp/
```

## ✅ Vérification

Une fois les fichiers en place, vérifiez avec :

### Windows
```powershell
Get-ChildItem -Path data -Recurse
```

### Mac/Linux
```bash
ls -R data/
```

Vous devriez voir :
```
data/
├── data-gouv-series-chrono.xlsx
└── regions-20180101-shp/
    ├── regions-20180101.shp
    ├── regions-20180101.shx
    ├── regions-20180101.dbf
    └── regions-20180101.prj
```

## 🚀 Lancez l'application

Une fois les données en place :

```bash
streamlit run app.py
```

Si tout est correct, vous verrez :
- ✅ "Chargement des données..." 
- ✅ L'application s'affiche sans erreur

## ❌ Problèmes courants

### Erreur "Fichier non trouvé"
**Cause:** Les fichiers ne sont pas au bon endroit

**Solution:**
1. Vérifiez que vous êtes dans le dossier `crime-analysis-app/`
2. Vérifiez que le dossier `data/` existe
3. Vérifiez les noms de fichiers (attention aux majuscules/minuscules)

### Erreur avec le shapefile
**Cause:** Il manque un des fichiers .shp, .shx, .dbf, ou .prj

**Solution:**
Tous les 4 fichiers doivent être présents ensemble dans le même dossier.

### Erreur "openpyxl"
**Cause:** La dépendance n'est pas installée

**Solution:**
```bash
pip install openpyxl
```

## 📝 Structure de vos données actuelles

D'après vos scripts originaux, vous avez :

1. **Excel:** `/Users/seydou/Downloads/process_2/data-gouv-series-chrono.xlsx`
   → À déplacer vers `data/data-gouv-series-chrono.xlsx`

2. **Shapefile:** `/Users/seydou/Downloads/regions-20180101-shp/`
   → À déplacer vers `data/regions-20180101-shp/`

## 🎯 Commande rapide pour vous

Si vos fichiers sont toujours aux emplacements d'origine :

```bash
# Créer la structure
mkdir -p data/regions-20180101-shp

# Copier les fichiers
cp /Users/seydou/Downloads/process_2/data-gouv-series-chrono.xlsx data/
cp -r /Users/seydou/Downloads/regions-20180101-shp/* data/regions-20180101-shp/

# Vérifier
ls -R data/

# Lancer l'app
streamlit run app.py
```

---

## 💡 Astuce

Si vous voulez utiliser d'autres emplacements, modifiez simplement `config.py` :

```python
# Dans config.py
EXCEL_FILE = Path("/mon/chemin/custom/data.xlsx")
SHAPEFILE_PATH = Path("/mon/chemin/custom/regions.shp")
```

Mais il est recommandé de garder la structure standard avec le dossier `data/`.
