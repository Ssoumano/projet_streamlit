# 👨‍💻 Documentation Développeur

## Architecture du projet

### Vue d'ensemble

L'application suit une architecture en couches :

```
┌─────────────────────────────────────┐
│       Interface Streamlit           │
│           (app.py)                  │
└───────────┬─────────────────────────┘
            │
┌───────────▼─────────────────────────┐
│        Pages (pages/)               │
│  - home.py                          │
│  - analyses.py                      │
│  - cartography.py                   │
└───────────┬─────────────────────────┘
            │
┌───────────▼─────────────────────────┐
│      Utilitaires (utils/)           │
│  - data_loader.py                   │
│  - visualizations.py                │
│  - predictions.py                   │
└───────────┬─────────────────────────┘
            │
┌───────────▼─────────────────────────┐
│    Configuration (config.py)        │
└─────────────────────────────────────┘
```

## 📦 Modules

### config.py
**Responsabilité** : Centraliser toutes les configurations
- Chemins de fichiers
- Constantes
- Paramètres par défaut

### utils/data_loader.py
**Responsabilité** : Gestion des données
- `load_crime_data()` : Charge le fichier Excel
- `load_shapefile()` : Charge les données géographiques
- `preprocess_data()` : Nettoie et transforme les données
- `get_regional_data()` : Agrège par région
- `create_crime_classes()` : Crée les classifications

**Utilise** : `@st.cache_data` pour optimiser les performances

### utils/visualizations.py
**Responsabilité** : Création de graphiques
- `create_pie_chart()` : Diagramme circulaire
- `create_time_series_plot()` : Évolution temporelle
- `create_choropleth_map()` : Carte choroplèthe
- `create_ranking_table()` : Tableau de classement

**Technologies** : matplotlib, geopandas

### utils/predictions.py
**Responsabilité** : Modèles prédictifs
- `train_linear_model()` : Entraînement du modèle
- `predict_crime_values()` : Prédictions de valeurs
- `predict_crime_classes()` : Prédictions de classes
- `create_forecast_visualization()` : Visualisation des prévisions

**Technologies** : scikit-learn

### pages/home.py
**Responsabilité** : Page d'accueil
- Vue d'ensemble des données
- Statistiques principales
- Graphiques interactifs de base

### pages/analyses.py
**Responsabilité** : Analyses détaillées
- Classements
- Classifications
- Comparaisons multi-années
- Statistiques globales

### pages/cartography.py
**Responsabilité** : Cartographie et prédictions
- Cartes choroplèthes
- Prédictions par classe
- Prévisions détaillées par région

## 🔧 Ajouter une nouvelle fonctionnalité

### Exemple : Ajouter un nouveau type de graphique

1. **Créer la fonction dans `utils/visualizations.py`**
```python
def create_bar_chart(df, year):
    """
    Crée un graphique en barres
    
    Args:
        df: DataFrame avec les données
        year: Année à visualiser
    
    Returns:
        matplotlib.figure.Figure
    """
    # Votre code ici
    return fig
```

2. **Importer dans la page concernée**
```python
from utils.visualizations import create_bar_chart
```

3. **Utiliser dans la page**
```python
fig = create_bar_chart(df_regional, selected_year)
st.pyplot(fig)
```

### Exemple : Ajouter une nouvelle page

1. **Créer `pages/new_page.py`**
```python
def show():
    st.title("Ma Nouvelle Page")
    # Votre code ici
```

2. **Ajouter dans `pages/__init__.py`**
```python
from . import new_page
__all__ = ['home', 'analyses', 'cartography', 'new_page']
```

3. **Ajouter la navigation dans `app.py`**
```python
page = st.sidebar.radio(
    "Choisir une page",
    ["🏠 Accueil", "📊 Analyses", "🗺️ Carto", "🆕 Nouvelle"]
)

if page == "🆕 Nouvelle":
    from pages import new_page
    new_page.show()
```

## 🎨 Conventions de code

### Nommage
- **Fonctions** : `snake_case` (ex: `load_crime_data`)
- **Classes** : `PascalCase` (ex: `CrimeAnalyzer`)
- **Constants** : `UPPER_CASE` (ex: `REGIONS_TO_EXCLUDE`)
- **Variables** : `snake_case` (ex: `df_regional`)

### Documentation
Toutes les fonctions doivent avoir une docstring :

```python
def my_function(param1, param2):
    """
    Description courte de la fonction
    
    Args:
        param1 (type): Description
        param2 (type): Description
    
    Returns:
        type: Description du retour
    """
    pass
```

### Gestion d'erreurs
Toujours gérer les exceptions :

```python
try:
    data = load_data()
except FileNotFoundError:
    st.error("Fichier non trouvé")
    return None
except Exception as e:
    st.error(f"Erreur : {e}")
    return None
```

## 🚀 Performance

### Caching
Utiliser `@st.cache_data` pour les fonctions coûteuses :

```python
@st.cache_data
def load_large_dataset():
    # Cette fonction ne sera exécutée qu'une fois
    return pd.read_csv("large_file.csv")
```

### Optimisations
- Charger les données une seule fois
- Éviter les boucles inutiles
- Utiliser vectorisation pandas quand possible
- Limiter les calculs dans les callbacks

## 🧪 Tests

### Tests manuels
1. Vérifier chaque page individuellement
2. Tester avec différentes sélections
3. Vérifier les cas limites (données manquantes, etc.)

### Points de test clés
- [ ] Chargement des données
- [ ] Affichage des graphiques
- [ ] Prédictions
- [ ] Navigation entre pages
- [ ] Gestion des erreurs

## 📝 Workflow de développement

1. **Créer une branche**
```bash
git checkout -b feature/nouvelle-fonctionnalite
```

2. **Développer et tester**
```bash
streamlit run app.py
```

3. **Commiter les changements**
```bash
git add .
git commit -m "Description du changement"
```

4. **Merger dans main**
```bash
git checkout main
git merge feature/nouvelle-fonctionnalite
```

## 🔍 Debugging

### Afficher les logs
```python
import logging
logging.basicConfig(level=logging.DEBUG)
logging.debug("Message de debug")
```

### Inspecter les données
```python
st.write(df.head())  # Afficher les premières lignes
st.write(df.shape)   # Dimensions du DataFrame
st.write(df.dtypes)  # Types des colonnes
```

### Mode debug Streamlit
```bash
streamlit run app.py --logger.level=debug
```

## 📚 Ressources

- [Streamlit Documentation](https://docs.streamlit.io/)
- [Pandas Documentation](https://pandas.pydata.org/docs/)
- [GeoPandas Documentation](https://geopandas.org/)
- [Scikit-learn Documentation](https://scikit-learn.org/)

## 🤝 Contribution

Pour contribuer :
1. Suivre les conventions de code
2. Documenter les nouvelles fonctions
3. Tester les changements
4. Créer une pull request descriptive
