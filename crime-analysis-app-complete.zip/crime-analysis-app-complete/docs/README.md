# 📊 Application d'Analyse de la Criminalité en France

Application Streamlit pour visualiser et analyser l'évolution de la criminalité en France par région.

## 🚀 Fonctionnalités

- **Visualisations interactives** : Graphiques, cartes et tableaux dynamiques
- **Analyse temporelle** : Évolution de la criminalité sur plusieurs années
- **Cartographie** : Visualisation géographique par région
- **Prédictions** : Estimation des tendances futures basée sur l'historique
- **Classifications** : Régions classées par niveaux de criminalité

## 📁 Structure du projet

```
crime-analysis-app/
├── app.py                      # Point d'entrée principal
├── config.py                   # Configuration et constantes
├── requirements.txt            # Dépendances Python
├── README.md                   # Documentation
├── data/                       # Dossier des données (à créer)
│   ├── data-gouv-series-chrono.xlsx
│   └── regions-20180101-shp/
│       └── regions-20180101.shp
├── pages/                      # Modules des pages
│   ├── __init__.py
│   ├── home.py                # Page d'accueil
│   ├── analyses.py            # Page d'analyses détaillées
│   └── cartography.py         # Page de cartographie
└── utils/                      # Modules utilitaires
    ├── __init__.py
    ├── data_loader.py         # Chargement des données
    ├── visualizations.py      # Fonctions de visualisation
    └── predictions.py         # Modèles de prédiction
```

## 🛠️ Installation

### Prérequis
- Python 3.8 ou supérieur
- pip (gestionnaire de packages Python)

### Étapes d'installation

1. **Cloner ou télécharger le projet**
```bash
cd crime-analysis-app
```

2. **Créer un environnement virtuel (recommandé)**
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

3. **Installer les dépendances**
```bash
pip install -r requirements.txt
```

4. **Préparer les données**
   - Créer un dossier `data/` à la racine du projet
   - Placer le fichier `data-gouv-series-chrono.xlsx` dans `data/`
   - Placer le dossier `regions-20180101-shp/` avec les fichiers shapefile dans `data/`

Structure attendue :
```
data/
├── data-gouv-series-chrono.xlsx
└── regions-20180101-shp/
    ├── regions-20180101.shp
    ├── regions-20180101.shx
    ├── regions-20180101.dbf
    └── regions-20180101.prj
```

## 🎯 Utilisation

### Lancer l'application

```bash
streamlit run app.py
```

L'application s'ouvrira automatiquement dans votre navigateur à l'adresse `http://localhost:8501`

### Navigation

L'application comporte trois pages principales :

1. **🏠 Accueil**
   - Vue d'ensemble des données
   - Distribution des crimes par région
   - Évolution temporelle

2. **📊 Analyses Détaillées**
   - Classements des régions
   - Classifications par niveau
   - Statistiques globales
   - Comparaisons multi-années

3. **🗺️ Cartographie**
   - Carte interactive des régions
   - Prédictions par classe
   - Prévisions détaillées

## 📊 Sources de données

Les données proviennent de :
- **Data.gouv** : Données officielles sur la criminalité en France
- **IGN** : Shapefile des régions françaises

## 🔧 Configuration

Pour modifier les paramètres de l'application, éditez le fichier `config.py` :
- Chemins des fichiers de données
- Régions à exclure
- Années de prédiction
- Couleurs et styles des graphiques

## 📈 Méthodologie des prédictions

Les prédictions sont basées sur une **régression linéaire** :
- Entraînement sur les données historiques
- Extrapolation pour les années futures
- Classification en tertiles (Faible/Moyen/Élevé)

⚠️ **Avertissement** : Ces prédictions sont des estimations basées sur les tendances passées et ne prennent pas en compte les événements futurs imprévisibles.

## 🤝 Contribution

Pour contribuer au projet :
1. Créer une branche pour votre fonctionnalité
2. Commiter vos changements
3. Créer une pull request

## 📝 Bonnes pratiques appliquées

- ✅ **Structure modulaire** : Séparation claire des responsabilités
- ✅ **Caching** : Utilisation de `@st.cache_data` pour optimiser les performances
- ✅ **Gestion d'erreurs** : Try/except avec messages informatifs
- ✅ **Documentation** : Docstrings pour toutes les fonctions
- ✅ **Configuration centralisée** : Évite les chemins en dur
- ✅ **Code DRY** : Pas de répétition de code
- ✅ **Interface utilisateur** : Navigation intuitive et visuels clairs

## 🐛 Dépannage

### Problème : "Fichier non trouvé"
- Vérifiez que les fichiers de données sont dans le dossier `data/`
- Vérifiez les chemins dans `config.py`

### Problème : Erreur d'import
- Assurez-vous que toutes les dépendances sont installées : `pip install -r requirements.txt`
- Vérifiez que vous êtes dans le bon environnement virtuel

### Problème : Carte vide
- Vérifiez que le shapefile est complet (tous les fichiers .shp, .shx, .dbf, .prj)
- Vérifiez que les noms de régions correspondent entre le fichier Excel et le shapefile

## 📧 Contact

Seydou Soumano
- LinkedIn : [linkedin.com/in/seydou-soumano](https://www.linkedin.com/in/seydou-soumano/)
- GitHub : [github.com/Ssoumano](https://github.com/Ssoumano)

## 📄 Licence

Ce projet est à usage éducatif.
