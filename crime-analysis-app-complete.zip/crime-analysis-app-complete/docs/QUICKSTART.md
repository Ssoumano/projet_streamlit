# 🚀 Guide de Démarrage Rapide

## Installation en 5 minutes

### 1️⃣ Préparer l'environnement

```bash
# Créer un environnement virtuel
python -m venv venv

# Activer l'environnement
# Sur Windows :
venv\Scripts\activate
# Sur Mac/Linux :
source venv/bin/activate

# Installer les dépendances
pip install -r requirements.txt
```

### 2️⃣ Préparer les données

Créer un dossier `data/` et y placer vos fichiers :

```
crime-analysis-app/
└── data/
    ├── data-gouv-series-chrono.xlsx
    └── regions-20180101-shp/
        ├── regions-20180101.shp
        ├── regions-20180101.shx
        ├── regions-20180001.dbf
        └── regions-20180101.prj
```

### 3️⃣ Lancer l'application

```bash
streamlit run app.py
```

🎉 L'application s'ouvre automatiquement dans votre navigateur !

---

## 🔍 Résolution rapide des problèmes

| Problème | Solution |
|----------|----------|
| Module non trouvé | `pip install -r requirements.txt` |
| Fichier non trouvé | Vérifier que les données sont dans `data/` |
| Port déjà utilisé | `streamlit run app.py --server.port 8502` |

---

## 📝 Modifications courantes

### Changer les couleurs
Éditez `.streamlit/config.toml`

### Ajouter des régions à exclure
Éditez `config.py` → `REGIONS_TO_EXCLUDE`

### Modifier les années de prédiction
Éditez `config.py` → `PREDICTION_YEARS`

---

## 💡 Astuces

- Utilisez `Ctrl+R` dans l'interface pour rafraîchir l'app
- Les données sont mises en cache automatiquement
- Consultez les logs dans le terminal pour le debug

---

Besoin d'aide ? Consultez le [README.md](README.md) complet !
