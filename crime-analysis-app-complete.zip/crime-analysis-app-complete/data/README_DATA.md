# 📁 Dossier Data

## ⚠️ IMPORTANT

Ce dossier doit contenir vos fichiers de données :

### Structure requise :

```
data/
├── data-gouv-series-chrono.xlsx
└── regions-20180101-shp/
    ├── regions-20180101.shp
    ├── regions-20180101.shx
    ├── regions-20180101.dbf
    └── regions-20180101.prj
```

## 📥 Comment obtenir les données ?

1. **Fichier Excel** : `data-gouv-series-chrono.xlsx`
   - Vous l'avez déjà !
   - Placez-le directement dans ce dossier `data/`

2. **Fichiers Shapefile** : dossier `regions-20180101-shp/`
   - Vous les avez déjà !
   - Créez un sous-dossier `regions-20180101-shp/` ici
   - Placez-y tous les fichiers .shp, .shx, .dbf, .prj

## 🚀 Une fois les données en place

Lancez l'application :

```bash
streamlit run app.py
```

## 💡 Astuce

Vos chemins actuels d'après vos scripts originaux :
- Excel : `/Users/seydou/Downloads/process_2/data-gouv-series-chrono.xlsx`
- Shapefile : `/Users/seydou/Downloads/regions-20180101-shp/`

Copiez-les simplement ici !
